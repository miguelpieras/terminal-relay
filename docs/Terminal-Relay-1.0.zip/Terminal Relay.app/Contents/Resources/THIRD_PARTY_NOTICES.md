# Third-party notices

Terminal Relay includes the following Swift packages:

- Sparkle 2.9.2 — MIT License
- SwiftTerm 1.15.0 — MIT License
- SwiftNIO SSH 0.14.1 — Apache License 2.0
- SwiftNIO 2.101.3 — Apache License 2.0
- Swift Crypto 4.5.1 — Apache License 2.0
- Swift Collections 1.6.0 — Apache License 2.0
- Swift System 1.7.5 — Apache License 2.0
- Swift Atomics 1.3.1 — Apache License 2.0
- Swift ASN.1 1.7.1 — Apache License 2.0
- Swift Argument Parser 1.8.2 — Apache License 2.0

The Apache-licensed components are distributed under the repository's
[Apache License 2.0](LICENSE).

Sparkle is distributed under the following terms:

> Copyright (c) 2006-2013 Andy Matuschak.
>
> Copyright (c) 2009-2013 Elgato Systems GmbH.
>
> Copyright (c) 2011-2014 Kornel Lesiński.
>
> Copyright (c) 2015-2017 Mayur Pawashe.
>
> Copyright (c) 2014 C.W. Betts.
>
> Copyright (c) 2014 Petroules Corporation.
>
> Copyright (c) 2014 Big Nerd Ranch.
>
> All rights reserved.
>
> Permission is hereby granted, free of charge, to any person obtaining a copy
> of this software and associated documentation files (the "Software"), to deal
> in the Software without restriction, including without limitation the rights
> to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
> copies of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in
> all copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
> OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
> SOFTWARE.

SwiftTerm is distributed under the following terms:

> Copyright (c) 2019-2022 Miguel de Icaza (https://github.com/migueldeicaza)
>
> Copyright (c) 2017-2019, The xterm.js authors (https://github.com/xtermjs/xterm.js)
>
> Copyright (c) 2014-2016, SourceLair Private Company (https://www.sourcelair.com)
>
> Copyright (c) 2012-2013, Christopher Jeffrey (https://github.com/chjj/)
>
> Permission is hereby granted, free of charge, to any person obtaining a copy
> of this software and associated documentation files (the "Software"), to deal
> in the Software without restriction, including without limitation the rights
> to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
> copies of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in
> all copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
> OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
> SOFTWARE.
